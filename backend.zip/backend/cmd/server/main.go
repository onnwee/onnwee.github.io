package main

import (
	"log"
	"net/http"
	"os"

	"github.com/gorilla/mux"
	"github.com/joho/godotenv"

	"github.com/onnwee/onnwee.github.io/backend/internal/api"
	"github.com/onnwee/onnwee.github.io/backend/internal/api/handlers"
)

func main() {
	// Load .env variables (only needed in dev)
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found")
	}

	// Initialize DB connection
	dbQueries, err := api.InitDB()
	if err != nil {
		log.Fatalf("Could not connect to database: %v", err)
	}

	// Set up shared server struct
	server := &api.Server{
		DB: dbQueries,
	}

	// Set up router
	router := mux.NewRouter()
	handlers.RegisterEventRoutes(router, server)
	handlers.RegisterPageViewRoutes(router, server)

	// Define port
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("Server running on port %s", port)
	if err := http.ListenAndServe(":"+port, router); err != nil {
		log.Fatalf("Server error: %v", err)
	}
}
