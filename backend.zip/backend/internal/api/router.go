package api

import (
	"net/http"

	"github.com/gorilla/mux"
)

func NewRouter(db *db.Queries) http.Handler {
	server := NewServer(db)

	r := mux.NewRouter()

	// Route registration
	RegisterHealthRoutes(r, server)
	RegisterLogRoutes(r, server)
	RegisterEventRoutes(r, server)
	RegisterPageViewRoutes(r, server)

	return r
}