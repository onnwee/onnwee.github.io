package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/gorilla/mux"
	"github.com/onnwee/onnwee.github.io/backend/internal/api"
	"github.com/onnwee/onnwee.github.io/backend/internal/db"
	"github.com/onnwee/onnwee.github.io/backend/internal/utils"
)

func RegisterLogRoutes(r *mux.Router, s *api.Server) {
	r.HandleFunc("/log", func(w http.ResponseWriter, r *http.Request) {
		var input db.CreateLogParams
		if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
			http.Error(w, "Invalid JSON", http.StatusBadRequest)
			return
		}
		input.occurred_at = time.Now()
		input.ip_address = utils.GetIP(r)

		if err := s.DB.CreateLog(r.Context(), input); err != nil {
			http.Error(w, "Failed to insert log", http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusCreated)
	}).Methods("POST")
}
