package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/gorilla/mux"
	"github.com/onnwee/onnwee.github.io/backend/internal/api"
	"github.com/onnwee/onnwee.github.io/backend/internal/db"
	"github.com/onnwee/onnwee.github.io/backend/internal/utils"
)

func RegisterEventRoutes(r *mux.Router, s *api.Server) {
	r.HandleFunc("/events", func(w http.ResponseWriter, r *http.Request) {
		var input db.CreateEventParams
		if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
			http.Error(w, "Invalid JSON", http.StatusBadRequest)
			return
		}

		input.OccurredAt = time.Now()
		input.IpAddress = utils.GetIP(r)

		if err := s.DB.CreateEvent(r.Context(), input); err != nil {
			http.Error(w, "Failed to insert event", http.StatusInternalServerError)
			return
		}

		w.WriteHeader(http.StatusCreated)
	}).Methods("POST")
}
