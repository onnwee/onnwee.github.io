-- name: CreateLog :one
INSERT INTO logs (level, message, context)
VALUES ($1, $2, $3)
RETURNING *;

-- name: GetLogByID :one
SELECT * FROM logs
WHERE id = $1;

-- name: ListLogs :many
SELECT * FROM logs
ORDER BY created_at DESC
LIMIT $1 OFFSET $2;

-- name: DeleteLog :exec
DELETE FROM logs
WHERE id = $1;
